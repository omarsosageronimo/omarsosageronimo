#!/bin/bash
#chkconfig:2345 98 5
#description:script to start mtpdaemon

/usr/bin/mtpdaemon
exit 0
